from ._axiomere import *

__doc__ = _axiomere.__doc__
if hasattr(_axiomere, "__all__"):
    __all__ = _axiomere.__all__